{\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww17240\viewh11360\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf0 \expnd0\expndtw0\kerning0
# Twitter - Part I\
\
This is a basic twitter app to read your tweets.\
\
Time spent: **X** hours spent in total\
\
## User Stories\
\
The following **required** functionality is completed:\
\
- [ ] User sees app icon in home screen and styled launch screen. (1pt)\
- [ ] User can log in. (1pt)\
- [ ] User can log out. (1pt)\
- [ ] User stays logged in across restarts. (1pt)\
- [ ] User can view tweets with the user profile picture, username, and tweet text. (6pts)\
\
The following **bonus** features are implemented:\
\
- [ ] User can pull to refresh. (1pt)\
- [ ] User can load past tweets infinitely. (2pts)\
\
## Video Walkthrough\
\
Here's a walkthrough of implemented user stories:\
\
<img src='http://i.imgur.com/link/to/your/gif/file.gif' title='Video Walkthrough' width='' alt='Video Walkthrough' />}